



__all__ = ["hangman", "Blackjack"]
